# Parallels Puppet Module for Boxen

## Usage

```puppet
include parallels
```

## Required Puppet Modules

* boxen

## Developing

Write code.

Run `script/cibuild`.

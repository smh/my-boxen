require 'spec_helper'

describe 'parallels' do
  it do
    should contain_package('Parallels Desktop 8').with({
      :provider => 'appdmg',
      :source   => 'http://www.parallels.com/directdownload/pd8',
    })
  end
end

# CCleaner Puppet Module for Boxen

## Usage

```puppet
include ccleaner
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.

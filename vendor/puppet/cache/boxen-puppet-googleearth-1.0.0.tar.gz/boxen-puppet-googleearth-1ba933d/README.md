# Google Earth Puppet Module for Boxen

Install [Google Earth](http://earth.google.com), and get the world’s geographic information at your fingertips.

## Usage

```puppet
include googleearth
```

## Required Puppet Modules

* `boxen`

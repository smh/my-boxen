# Daisy Disk Puppet Module for Boxen ![Build Status](https://travis-ci.org/geetarista/puppet-daisy_disk.png)

Installs the Daisy Disk Mac app.

## Usage

Install the latest version of Daisy Disk:

```puppet
include daisy_disk
```

Install Diasy Disk 1:

```puppet
include daisy_disk::1
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
